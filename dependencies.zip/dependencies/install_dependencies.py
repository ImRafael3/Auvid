#!/usr/bin/env python3
"""
Cross-platform dependency installer for make_video.py
Works on Windows, macOS and Linux.
Only installs what is missing.
"""

import sys
import os
import subprocess
import importlib.util


def is_module_available(module_name):
    return importlib.util.find_spec(module_name) is not None


def has_system_ffmpeg():
    candidates = ["ffmpeg", "/usr/bin/ffmpeg", "/usr/local/bin/ffmpeg"]
    for candidate in candidates:
        try:
            result = subprocess.run(
                [candidate, "-version"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5
            )
            if result.returncode == 0:
                return True
        except (FileNotFoundError, OSError, subprocess.TimeoutExpired):
            continue
    try:
        cmd = ["where", "ffmpeg"] if sys.platform.startswith("win") else ["which", "ffmpeg"]
        result = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
        return result.returncode == 0
    except (FileNotFoundError, OSError, subprocess.TimeoutExpired):
        return False


def run_pip_install(package):
    print("  Installing " + package + "...")
    try:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "--upgrade", package],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE
        )
        print("  " + package + " installed.")
        return True
    except subprocess.CalledProcessError:
        print("  Failed to install " + package + ".")
        return False


def main():
    print("=" * 50)
    print("  DEPENDENCY INSTALLER - make_video.py")
    print("=" * 50)
    print()
    print("Python: " + sys.version.split()[0])
    print("System: " + sys.platform)
    print()

    something_installed = False
    all_ok = True

    # 1. Pillow
    print("[1/2] Pillow")
    if is_module_available("PIL"):
        print("  Already installed. Skipping.")
    else:
        print("  Not found.")
        if run_pip_install("Pillow"):
            something_installed = True
        else:
            all_ok = False
    print()

    # 2. FFmpeg
    print("[2/2] FFmpeg")
    has_imageio = is_module_available("imageio_ffmpeg")
    has_ffmpeg = has_system_ffmpeg()

    if has_imageio:
        print("  imageio-ffmpeg already installed. Skipping.")
    elif has_ffmpeg:
        print("  System FFmpeg found. Skipping imageio-ffmpeg.")
    else:
        print("  Not found.")
        print("  Trying to install imageio-ffmpeg...")
        if run_pip_install("imageio-ffmpeg"):
            something_installed = True
        else:
            all_ok = False
            print()
            print("  Manual install options:")
            print("  Windows : https://www.gyan.dev/ffmpeg/builds/")
            print("  macOS   : brew install ffmpeg")
            print("  Linux   : sudo apt install ffmpeg")
    print()

    print("=" * 50)
    if all_ok:
        if something_installed:
            print("  Done. You can now run make_video.py")
        else:
            print("  All dependencies already installed.")
            print("  Nothing to download.")
        print()
        print("  Run:  python make_video.py")
    else:
        print("  Some dependencies could not be installed.")
        print("  Check the errors above.")
    print("=" * 50)

    try:
        if sys.stdin.isatty():
            input("\nPress Enter to close...")
    except (EOFError, KeyboardInterrupt):
        pass


if __name__ == "__main__":
    main()
